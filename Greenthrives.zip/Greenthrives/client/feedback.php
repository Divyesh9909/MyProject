<?php include("header_pages.php");?>
<?php 										
if($_SERVER["REQUEST_METHOD"]=="POST")
{
	if(isset($_POST["feedback_desc"])) 
	{
		
		$oid=$_GET['id'];
		$feedback_desc=$_POST["feedback_desc"];
		$feedback_date=date("Y/m/d");
		
		if($feedback_desc!="")
		{
			$sql3="insert into datatables_feedback(feedback_desc,feedback_date,order_id_id)values
			('".$feedback_desc."','".$feedback_date."','".$oid."')";
			
			
			
		
			$result3=mysqli_query($conn,$sql3);
			
			
			
			
			if($result3)
			{
				echo "<meta http-equiv='refresh' content='0;url=home.php'/>";
			}
		}
		else
		{
			echo "null values";
		}
	}
}?>
		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Feedback</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">Feedback</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Login Register Area Strat-->
		<div class="login-register-area mb-80">
		    <div class="container">
		        <div class="row">
                    <!--Login Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register">
		                    <div class="form-login-title">
		                        <h2></h2>
		                    </div>
		                    <div class="login-form">
		                        <form action="#" method="post">
		                            <div class="form-fild">
		                                <p><label>Send your Message<span class="required">*</span></label></p>
		                                <input name="feedback_desc" value="" type="text">
		                            </div>
		                            
		                            <div class="login-submit">
		                                <button type="submit" class="form-button">Send</button>
		                                
		                            </div>
		                            
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Login Form End-->
		            
		        </div> 
		    </div>
		</div>
		<!--Login Register Area End-->
		<?php include("footer.php");?>