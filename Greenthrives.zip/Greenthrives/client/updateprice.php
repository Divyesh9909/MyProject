<?php
session_start();
require_once("../config/connection.php");
$id = $_GET['cid'];
$q= $_GET['qty'];
$uid = $_SESSION['u_id'];


$get ="select * from datatables_cart c join 
datatables_product p join datatables_product_details pd
where c.product_id_id = p.id and p.id = pd.product_id_id
and c.id = $id";


$result1 = mysqli_query($conn,$get);
$row = mysqli_fetch_array($result1);

$p = $row['product_price'];

$amt = ($p) * $q;



$sql = "update datatables_cart set qty=$q , 
amount = $amt where id = $id";

//$result2 = mysqli_query($conn,$sql);
if ($conn->query($sql) === TRUE) {
	  echo "";
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	}

	 
	$uid = $_SESSION['u_id'];
	$sql5="select sum(amount)as amount from datatables_cart where user_id_id='".$uid."' and flag='0'";						
	$result5=mysqli_query($conn,$sql5);
	$row5=mysqli_fetch_array($result5);
	$total=$row5['amount'];


echo $total;

?>