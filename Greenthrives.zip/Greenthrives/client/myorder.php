<?php include("header_pages.php");
if(isset($_GET['cid']))
	
{
	$id=$_GET['address_id'];
	$oid = $_GET['cid'];
	$sql="update datatables_order set payment_status=1 where id = $oid";
	$r = mysqli_query($conn,$sql);
}

?>

		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>My Orders</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">My Orders</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Shopping Cart Area Strat-->
		<div class="Shopping-cart-area mb-110">
		    <div class="container">
		        <div class="row">
		            <div class="col-12">
		                <form action="#">
		                    <div class="table-content table-responsive">
		                        <table class="table">
		                            <thead>
		                                <tr>
		                                    
		                                    <th class="plantmore-product-thumbnail">Order Date</th>
		                                    <th class="cart-product-name">Order Status</th>
		                                    <th class="plantmore-product-price">Payment Status</th>
											<th class="plantmore-product-price">Address</th>
											
											<th class="plantmore-product-quantity">View Details</th>
											<th class="plantmore-product-quantity">Feedback</th>
		                                   
		                                </tr>
		                            </thead>
		                            <tbody>
									<?php
							
							$uid = $_SESSION['u_id'];
							$sql="select o.id,o.order_status,o.payment_status,o.order_date,o.user_id_id from datatables_order o JOIN datatables_orderdetails od JOIN datatables_product p 
							where o.id=od.order_id_id and p.id=od.product_id_id and o.user_id_id='".$uid."'";


								
							$result=mysqli_query($conn,$sql);
							//while($row = mysqli_fetch_assoc($result)){
							//foreach($row as $cname => $cvalue){
							//print "$cname: $cvalue\t";}
							//}
							//die;

						while($row=mysqli_fetch_array($result))
						{ 
							$oi=$row['id'];?>
		                                <tr>
		                                    
		                                    <td class="plantmore-product-thumbnail"><?php echo $row['order_date']?></td>
		                                    <td class="plantmore-product-name"><?php if($row['order_status']==1)
												{
								
												echo "<h6>Accepted</h6>";
							 
												}?>
												</td>
		                                    <td class="plantmore-product-price"><?php 
											if($row['payment_status']==1)
											
											{
												echo "<h6 style='color:green'>CASH</h6>";
											}?>
											</td>
											
												<?php
							
											$sql3="select * from datatables_address where user_id_id='".$uid."' and id='".$id."'";
											$result3=mysqli_query($conn,$sql3);

											while($row3=mysqli_fetch_array($result3))
											{
												?> 
											<td class="product-subtotal"><?php echo $row3['house_no'];?>,<?php echo $row3['building_name'];?>,<?php echo $row3['address_type'];?></td>
											<?php } ?>
		                                    
		                                    <td class="product-subtotal"><a style="color:blue;cursor:pointer" href="myorder2.php?id=<?php echo $oi;?>">View</td>
											<td class="product-subtotal"><a style="color:blue;cursor:pointer" href="feedback.php?id=<?php echo $oi;?>">Give Feedback</td>
		                                </tr>
										<?php } ?>
		                                
		                            </tbody>
		                        </table>
		                    </div>
		                    
		                    
		                </form>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Shopping Cart Area End-->
	<?php include("footer.php");?>