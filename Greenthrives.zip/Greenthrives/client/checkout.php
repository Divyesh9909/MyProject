<?php include("header_pages.php");?>
<?php require_once('../config/connection.php');
	
	$uid=$_GET['uid'];
	$id=$_GET['id'];
  $oid=$_GET['id'];
  $sql="Select * from datatables_order o join datatables_cart c join datatables_product_details pd 
  join datatables_orderdetails od join datatables_product p 
	where o.id=od.order_id_id and c.id=od.cart_id_id and p.id=pd.product_id_id and p.id=od.product_id_id and o.id='".$oid."'";
	
	$result=mysqli_query($conn,$sql);


?>
 <?php
						if ($_SERVER["REQUEST_METHOD"] =="POST")
						{
							if (isset($_POST["number"]) &&  isset($_POST["name"]) && isset($_POST["landmark"]) && isset($_POST["city"]) && isset($_POST["type"]))
							{ 	
								$id=$_SESSION['u_id'];
								$name=$_POST["name"];
								
								$number=$_POST["number"];
								
								$landmark=$_POST["landmark"];
								
								$city=$_POST["city"];	
								$type=$_POST["type"];
										   
								if($number!=''  && $name!='' && $landmark!='' &&
								 $city!='' && $type!='')
								{
									$sql3 = "insert into datatables_address(house_no,building_name,landmark,city,address_type,user_id_id)
											values('".$number."','".$name."','".$landmark."','".$city."','".$type."','".$id."')";									
									
									
									$result3=mysqli_query($conn,$sql3);
											   
									if($result3)
									{
										echo "<meta http-equiv='refresh' content='3;url=myorder.php>";
									}
								}
								else
								{
										echo "hello";
								}
							}
							else
							{
								echo"value not set";
							}	   
						}
					?>									
                                 

		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Checkout</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">Checkout</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Checkout Area Strat-->
		<div class="checkout-area mb-80">
		    <div class="container">
		        
		        <div class="row">
		            <div class="col-lg-6 col-12">
		                <form action="#" method="post">
		                    <div class="checkbox-form">
		                        <h3>Billing Details</h3>
		                        <div class="row">
		                            <div class="col-md-12">
		                                <div class="country-select clearfix">
		                                    <label>Address Type <span class="required">*</span></label>
		                                    <select class="wide">
												<?php
											   $sql2="select * from datatables_address where user_id_id=$uid";
											   $result2=mysqli_query($conn,$sql2);
											   while($row2=mysqli_fetch_array($result2))
											   {	
													$aid=$row2['id'];		
												   
												   
												  ?>
												   
													
                                                  <option value="<?php echo $row2["id"]?>"><?php echo $row2["address_type"]?>,<?php echo $row2["building_name"]?></option>
											   
											   <?php } ?>
                                           </select>
		                                </div>
		                            </div>
									
		                            <div class="col-md-12">
		                                <div class="checkout-form-list">
		                                    
		                                   
		                                </div>
		                            </div>
									
		                            
		                            
		                            
		                            
		                            
		                            
		                        </div>
		                        <div class="different-address">
		                            <div class="ship-different-title">
		                                <h3>
                                            <label>Ship to a different address?</label>
                                            <input id="ship-box" type="checkbox">
                                        </h3>
		                            </div>
		                            <div id="ship-box-info" class="row">
		                                
                                        <div class="col-md-12">
                                            <div class="checkout-form-list">
                                                <label>House No<span class="required">*</span></label>
                                                <input placeholder="" type="text" name="number">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="checkout-form-list">
                                                <label>Name<span class="required">*</span></label>
                                                <input placeholder="" type="text" name="name">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="checkout-form-list">
                                                <label>Landmark</label>
                                                <input placeholder="" type="text" name="landmark">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="checkout-form-list">
                                                <label>City <span class="required">*</span></label>
                                                <input  type="text" name="city">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12">
                                            <div class="checkout-form-list">
                                                <label>Address Type <span class="required">*</span></label>
                                                <input type="text" name="type">
                                            </div>
                                        </div>
										
                                        
                                        
                                        
                                        
		                            </div>
		                            
		                        </div>
		                    </div>
		               
		            </div>
		            <div class="col-lg-6 col-12">
		                <div class="your-order">
		                    <h3>Your order</h3>
		                    <div class="your-order-table table-responsive">
		                        <table class="table">
		                            <thead>
		                                <tr>
		                                    <th class="cart-product-name">Product</th>
		                                    <th class="cart-product-total">Price</th>
		                                </tr>
		                            </thead>
		                            <tbody>
										
									<?php
									while($row=mysqli_fetch_array($result))
									{
										?>
		                                <tr class="cart_item">
		                                  <td class="cart-product-name"><?php echo $row['product_name']?><strong class="product-quantity"> × <?php echo $row['qty']?></strong></td>
		                                  <td class="cart-product-total"><span class="amount">&#8377;<?php echo $row['product_price']?></span></td>  
		                                </tr>
									<?php } ?>
		                                
		                            </tbody>
		                            <tfoot>
		                                
		                                <tr class="order-total">
		                                    <th>Order Total</th>
		                                    <td><strong><span class="amount">&#8377;<?php echo $_GET['amt']?></span></strong></td>
		                                </tr>
		                            </tfoot>
		                        </table>
		                    </div>
		                    <div class="payment-method">
		                        <div class="payment-accordion">
		                            <div id="accordion">
                                      <div class="card">
                                        <div class="card-header" id="#payment-1">
                                          <h5 class="panel-title">
                                            <a class="" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                              Cash On Delivery.
                                            </a>
                                          </h5>
                                        </div>
                                        <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                          <div class="card-body">
                                            <p><button><a href="myorder.php?&cid=<?php echo $_GET['id']?>&address_id=<?php echo $aid?>">Pay with cash upon delivery.</a></button></p>
                                          </div>
                                        </div>
                                      </div>
                                      
                                      
                                    </div>
                                    
		                        </div>
		                    </div>
							
										 </form>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Checkout Area End-->
		
<?php include("footer.php");?>