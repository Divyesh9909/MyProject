<?php 
session_start();
require_once('../config/connection.php');

	  $d = date("Y-m-d");
	  $uid = $_SESSION['u_id'];
	  $pid = $_GET['pid'];
	  $qty = $_GET['qty'];

	  $sql1 = "select * from datatables_product p JOIN datatables_category c JOIN datatables_gallary g 
				JOIN datatables_product_details pd 
				where p.category_id_id=c.id and p.id=g.product_id_id and
				p.id=pd.product_id_id AND p.id= '".$pid."'";
				
				
		
	  
	  $result1 = mysqli_query($conn,$sql1);
	  $row1=mysqli_fetch_array($result1);
	  
	  $amount = $row1['product_price'];		

	  $total = $amount * $qty;
	  
	  $sql3 = "select * from datatables_cart where product_id_id=$pid and user_id_id=$uid and flag='0' ";
	  
	  
	  $result3 = mysqli_query($conn,$sql3);
	  
	  if(mysqli_num_rows($result3) == 1)
	  {
		$row3 = mysqli_fetch_array($result3);  
		$q = $row3['qty'];
		$amt = $row3['amount'];
		$amt = $amt + $total;
		$nq = $q + $qty;		
		$sql = "update datatables_cart set qty = $nq , amount = $amt 
		where user_id_id = $uid and product_id_id=$pid";
		
	  }
	  else
	  {
	  $sql="insert into datatables_cart(added_date,user_id_id,product_id_id,qty,amount,flag)
	  values('".$d."','".$uid."','".$pid."','".$qty."','".$total."',0)";
		
	  }
	  $result=mysqli_query($conn,$sql);
	  
	  if($result)
	  {
		  echo "<meta http-equiv='refresh' content='0;url=cart.php'>"; 
	  }
	  else
	  {
		  echo "<meta http-equiv='refresh' content='0;url=single-product.php'>";
					  
	  }

  
 ?>