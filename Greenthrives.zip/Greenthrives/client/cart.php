<?php include("header_pages.php");?>

<script src="jquery-3.4.1.js" type="text/javascript"></script>

<script>
function getprice(val) 
{
	
	var q = $("#qty-"+val).val();
	var p = $("#amount-"+val).val();
	
	$.ajax({
			type:"GET",
			url:"updateprice.php",
			data:{cid:val,qty:q,amt:p},
			success: function(data){
				$("#total").html(data);
			}
	});
}
</script>

		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Shopping Cart</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">Shopping Cart</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Shopping Cart Area Strat-->
		<div class="Shopping-cart-area mb-110">
		    <div class="container">
		        <div class="row">
		            <div class="col-12">
		                <form action="#">
		                    <div class="table-content table-responsive">
		                        <table class="table">
		                            <thead>
		                                <tr>
		                                    <th class="plantmore-product-remove">remove</th>
		                                    <th class="plantmore-product-thumbnail">images</th>
		                                    <th class="cart-product-name">Product</th>
		                                    <th class="plantmore-product-price">Unit Price</th>
		                                    <th class="plantmore-product-quantity">Quantity</th>
		                                    <th class="plantmore-product-subtotal">Total</th>
		                                </tr>
		                            </thead>
		                            <tbody>
									<?php
									
							$uid = $_SESSION['u_id'];

								$sql="select c.id,c.qty,c.amount,p.product_name,c.product_id_id,c.user_id_id,pd.product_price from datatables_cart c JOIN datatables_product p JOIN datatables_user u 
								JOIN datatables_product_details pd 
								where flag='0' and p.id=c.product_id_id and u.id=c.user_id_id and p.id=pd.product_id_id 
								and c.user_id_id='".$uid."'";

								
							$result=mysqli_query($conn,$sql);
							
							//while($row = mysqli_fetch_assoc($result)){
							//foreach($row as $cname => $cvalue){
							//print "$cname: $cvalue\t";}
							//}
							
							
							
							?>
							
							
							<?php
							
						
							
						while($row=mysqli_fetch_array($result))
						{
							$cid=$row['id'];
							$product_id=$row['product_id_id'];
							$query_images = "SELECT * FROM datatables_gallary WHERE product_id_id = {$product_id} LIMIT 1";
							$result_gallary1 = mysqli_query($conn,$query_images);
							while($gallary_row=mysqli_fetch_assoc($result_gallary1))
							{	
									
							
								
									 	
												
						?>  			
		                                <tr>
										
		                                    <td class="plantmore-product-remove"><a href="cart_delete.php?id=<?php echo $cid?>"><i class="fa fa-times"></i></a></td>
											
								
		                                    <td class="plantmore-product-thumbnail"><a href="#"><img src="../gallary/<?php echo $gallary_row['gallary_path']?>" alt=""></a></td>
							<?php } ?>
		                                    <td class="plantmore-product-name"><a href="#"><?php echo $row['product_name'];?></a></td>
		                                    <td class="plantmore-product-price"><span class="amount">&#8377;<?php echo $row['product_price']; ?></span></td>
		                                    <td class="plantmore-product-quantity">
		                                        <input value=<?php echo $row['qty'];?>
						                           onClick="getprice(<?php echo $cid?>)"
														id = "qty-<?php echo $cid; ?>" type="number">
		                                    </td>
		                                    <td class="product-subtotal"><span class="amount"><div id="amount-<?php echo $id;?>">&#8377;<?php echo $row['amount'];?></div></span></td>
							
										</tr>
										<?php } ?>
										
		                                
		                            </tbody>
		                        </table>
								<?php 
							$uid=$_SESSION['u_id'];
							$sql5="select sum(amount)as amount from datatables_cart where user_id_id='".$uid."' and flag='0'";
						
							$result5=mysqli_query($conn,$sql5);
							$row5=mysqli_fetch_array($result5);
							$amt=$row5['amount'];
						?>
		                    </div>
		                   
		                    <div class="row">
		                        <div class="col-md-5 ml-auto">
		                            <div class="cart-page-total">
		                                <h2>Cart totals</h2>
		                                <ul>
		                                    
		                                    <li>Total <span id="total">&#8377;<?php echo $row5['amount'];?></span></li>
		                                </ul>
		                                <a href="checkout2.php?amt=<?php echo $amt?>" >Proceed to checkout</a>
		                            </div>
		                        </div>
		                    </div>
		                </form>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Shopping Cart Area End-->
		<?php include("footer.php");?>