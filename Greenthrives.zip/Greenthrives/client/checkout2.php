<?php
session_start();
require_once('../config/connection.php');

$uid=$_SESSION['u_id'];
$sql="select * from datatables_cart where user_id_id='".$uid."' and flag='0'";
$result=mysqli_query($conn,$sql);

$d=date("Y-m-d");
$t=$_GET['amt'];
$sql1="insert into datatables_order(order_date,order_status,user_id_id)values('".$d."',1,'".$uid."')";
$result1=mysqli_query($conn,$sql1);
$oid=mysqli_insert_id($conn);

while($row=mysqli_fetch_array($result))
{
	$pid=$row['product_id_id'];
	$cid=$row['id'];
	$sql2="insert into datatables_orderdetails(order_id_id,product_id_id,cart_id_id)values('".$oid."','".$pid."','".$cid."')";
	$result2=mysqli_query($conn,$sql2);
}
$sql3="update datatables_cart set flag='1' where user_id_id='".$uid."'";
//$result3=mysqli_query($conn,$sql3);
if ($conn->query($sql3) === TRUE) {
	  echo "";
	} else {
	  echo "Error: " . $sql3 . "<br>" . $conn->error;
	}


echo"<meta http-equiv='refresh' content='0;url=checkout.php?id=$oid&amt=$t&uid=$uid'>";
?>
