<?php include("header_pages.php");?>
		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>About Us</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li class="active">About Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--About Us Area Start-->
		<div class="about-us-area">
		    <div class="container-fluid p-0">
		        <div class="row no-gutters">
		            <div class="col-md-12 col-lg-6">
		                <div class="about-us-img img-full">
		                    <img src="img/about/product11.jpg" alt="">
		                </div>
		            </div>
		            <div class="col-md-12 col-lg-6">
		                <div class="about-us-content">
		                    <h2><strong>About US</strong></h2>
		                    <p>We provide the best products. You can buy our product without any hesitation because our products are trust worthy and high quality.clients belive in us and always buy our products happily.

							Some of our customer say’s that they trust us and buy our product without any worry because they belive us and always happy to buy from us.</p>
		                    
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--About Us Area End-->
		<!--Fun Factor Area Start-->
		<div class="fun-factor-area">
		    <div class="container-fluid p-0">
		        <div class="row no-gutters">
                    <!--Single Fun Factor Start-->
		            <div class="col-lg-3 col-md-6">
		                <div class="fun-factor-wrap">
		                    <div class="fun-factor-icon">
		                        <img src="img/icon/fun-fact1.png" alt="">
		                    </div>
		                    <div class="fun-facttor-content">
		                        <div class="fun-facttor-number">
									<?php
									require_once('../config/connection.php');
									$users="select count(*) as total_users from datatables_user";
									$result=mysqli_query($conn,$users);
									$row=mysqli_fetch_array($result);
									$user_count=$row['total_users'];?>
							
		                            <h2><span class="counter"><?php echo $row['total_users'] ?></span></h2>
		                        </div>
		                        <div class="fun-facttor-title">
		                            <h5>happy customers</h5>
		                        </div>
		                    </div>
		                </div>
		            </div>
		            <!--Single Fun Factor End-->
                    <!--Single Fun Factor Start-->
		            <div class="col-lg-3 col-md-6">
		                <div class="fun-factor-wrap">
		                    <div class="fun-factor-icon">
		                        <img src="img/icon/fun-fact2.png" alt="">
		                    </div>
		                    <div class="fun-facttor-content">
		                        <div class="fun-facttor-number">
									<?php
									require_once('../config/connection.php');
									$products="select count(*) as total_products from datatables_product";
									$result2=mysqli_query($conn,$products);
									$row2=mysqli_fetch_array($result2);
									$product_count=$row2['total_products'];

					?>
		                            <h2><span class="counter"><?php echo $row2['total_products'] ?></span></h2>
		                        </div>
		                        <div class="fun-facttor-title">
		                            <h5>Total Products</h5>
		                        </div>
		                    </div>
		                </div>
		            </div>
		            <!--Single Fun Factor End-->
                    <!--Single Fun Factor Start-->
		            <div class="col-lg-3 col-md-6">
		                <div class="fun-factor-wrap">
		                    <div class="fun-factor-icon">
		                        <img src="img/icon/fun-fact3.png" alt="">
		                    </div>
		                    <div class="fun-facttor-content">
		                        <div class="fun-facttor-number">
									<?php
									require_once('../config/connection.php');
									$feedbacks="select count(*) as total_feedbacks from datatables_feedback";
									$result3=mysqli_query($conn,$feedbacks);
									$row3=mysqli_fetch_array($result3);
									$feedback_count=$row3['total_feedbacks'];

					?>
								
		                            <h2><span class="counter"><?php echo $row3['total_feedbacks']?></span></h2>
		                        </div>
		                        <div class="fun-facttor-title">
		                            <h5>Total feedbacks</h5>
		                        </div>
		                    </div>
		                </div>
		            </div>
		            <!--Single Fun Factor End-->
                    <!--Single Fun Factor Start-->
		            <div class="col-lg-3 col-md-6">
		                <div class="fun-factor-wrap">
		                    <div class="fun-factor-icon">
		                        <img src="img/icon/fun-fact4.png" alt="">
		                    </div>
		                    <div class="fun-facttor-content">
		                        <div class="fun-facttor-number">
										<?php 
					require_once('../config/connection.php');
					$orders="select count(*) as total_orders from datatables_order";
					$result1=mysqli_query($conn,$orders);
					$row1=mysqli_fetch_array($result1);
					$order_count=$row1['total_orders'];

					?>
		                            <h2><span class="counter"><?php echo $row1['total_orders']?></span></h2>
		                        </div>
		                        <div class="fun-facttor-title">
		                            <h5>COMPLETE PROJECTS</h5>
		                        </div>
		                    </div>
		                </div>
		            </div>
		            <!--Single Fun Factor End-->
		        </div>
		    </div>
		</div>
		<!--Fun Factor Area End-->
		<?php include("footer.php");?>