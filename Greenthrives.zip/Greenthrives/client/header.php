<?php require_once('../config/connection.php');
session_start();?>
<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from demo.hasthemes.com/plantmore-preview/plantmore-v5/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 11:57:55 GMT -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>Plantmore - Responsive Bootstrap 4 eCommerce Template</title>
	<meta name="description" content="">
	<meta name="robots" content="noindex, follow" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, follow" />
	<!-- Place favicon.ico in the root directory -->
	<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!--All Css Here-->
    
    <!-- Bootstrap CSS-->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Linearicon CSS-->
    <link rel="stylesheet" href="css/linearicons.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Animate CSS-->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Owl Carousel CSS-->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<!-- Slick CSS-->
	<link rel="stylesheet" href="css/slick.css">
	<!-- Meanmenu CSS-->
	<link rel="stylesheet" href="css/meanmenu.min.css">
	<!-- Easyzoom CSS-->
	<link rel="stylesheet" href="css/easyzoom.css">
	<!-- Venobox CSS-->
	<link rel="stylesheet" href="css/venobox.css">
	<!-- Jquery Ui CSS-->
	<link rel="stylesheet" href="css/jquery-ui.css">
	<!-- Nice Select CSS-->
	<link rel="stylesheet" href="css/nice-select.css">
	<!-- Style CSS -->
	<link rel="stylesheet" href="style.css">
	<!-- Responsive CSS -->
	<link rel="stylesheet" href="css/responsive.css">
	<!-- Modernizr Js -->
	<script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
	<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->

	<div class="wrapper">
		<!--Header Area Start-->
		<header>
		    <div class="header-container">
		        <div class="header-area header-absolute header-sticky pt-30 pb-30">
                    <div class="container-fluid pl-50 pr-50">
                        <div class="row">
                            <!--Header Logo Start-->
                            <div class="col-lg-3 col-md-3">
                                <div class="logo-area">
                                    <a href="index.html">
                                        <img src="img/logo/logo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <!--Header Logo End-->
                            <!--Header Menu And Mini Cart Start-->
                            <div class="col-lg-9 col-md-9 text-lg-right">
                                <!--Main Menu Area Start-->
                                <div class="header-menu">
                                    <nav>
                                        <ul class="main-menu">
                                            <li><a href="home.php">home</a>
                                                
                                            </li>
                                           
                                                <!--Dropdown Menu Start-->
												<?php
												$category="select * from datatables_category where parent_category_id IS NULL";
												$q=mysqli_query($conn,$category);
									
												while($row=mysqli_fetch_array($q))
												{
													$id=$row['id'];
												?>
												<li><a href="#"><?php echo $row["category_name"];?></a>
                                                <ul class="dropdown">
													<?php
												$subcategory="select * from datatables_category where parent_category_id='".$id."'";
												$q1=mysqli_query($conn,$subcategory);
									
												while($row1=mysqli_fetch_array($q1))
												{
													$id=$row1['id'];
									    
												?>  
                                                 
                                                    <li><a href="shop.php?id=<?php echo$id?>"><?php echo $row1["category_name"];?></a></li>                                                    
													<?php } ?>
												</ul>
                                                <!--Dropdown Menu End-->
                                            </li>
											<?php } ?>
											
														
                                        </ul>
										
                                    </nav>
                                </div>
                                <!--Main Menu Area End-->
                                <!--Header Option Start--> 
								
														<?php
														if(isset($_SESSION['u_name']))
														{
														?>
                                <div class="header-option">
                                    <div class="mini-cart-search">
                                        <div class="mini-cart">
                                            <a href="#">
                                                <span class="cart-icon">
                                                   
                                                </span>
                                                
                                            </a>
											
                                           <!--Cart Dropdown Start-->
                                          <div class="cart-dropdown">
												<?php
												$uid=$_SESSION['u_id'];
												$sql3="select * from datatables_cart c JOIN datatables_product p JOIN datatables_user u 
												JOIN datatables_product_details pd
												where flag='0' and p.id=c.product_id_id and u.id=c.user_id_id and p.id=pd.product_id_id 
												 and c.user_id_id='".$uid."'";
											
												$result3=mysqli_query($conn,$sql3);
												while($row3=mysqli_fetch_array($result3))
												{
												   ?>
												<ul>
													<?php
														
														$product_id = $row3['product_id_id'];
														$query_images = "SELECT * FROM datatables_gallary WHERE product_id_id = {$product_id} LIMIT 1";
														
														$result_gallary1 = mysqli_query($conn,$query_images);
														
														while($gallary_row=mysqli_fetch_assoc($result_gallary1))
														{
								
														?>
                                                  <li class="single-cart-item">
												  
														
                                                      <div class="cart-img">
                                                          <a href="#"><img src="../gallary/<?php echo $gallary_row['gallary_path']?>" alt=""></a>
                                                      </div>
													
                                                      <div class="cart-content">
                                                          <h5 class="product-name"><a href="#"><?php echo $row3['product_name'];?></a></h5>
                                                          <span class="cart-price"><?php echo $row3['qty']?> × <?php echo $row3['product_price']?></span>
                                                      </div>
                                                      
                                                  </li>
											   <?php } ?>
											   
                                                  
                                               </ul>
											   	<?php } ?>
											  
												
												<?php 
											$sql5="select sum(amount)as amount from datatables_cart where user_id_id='".$uid."' and flag='0'";
						
											$result5=mysqli_query($conn,$sql5);
											$row5=mysqli_fetch_array($result5);
											$amt=$row5['amount'];
										?>
                                              <p class="cart-subtotal"><strong>Subtotal:</strong> <span class="float-right">&#8377;<?php echo $row5['amount'];?></span></p> 
                                              <p class="cart-btn">
                                                  
                                                  <a href="checkout2.php?amt=<?php echo $amt?>">Checkout</a>
                                              </p>
                                          </div>
                                           <!--Cart Dropdown End--> 
                                        </div>
														<?php }?>
                                        <div class="currency">
                                            <div class="currency-box">
                                                <a href="#"><i class="fa fa-th"></i></a>
                                                <div class="currency-dropdown">
                                                    <ul class="menu-top-menu">
														
														
														<?php
														if(isset($_SESSION['u_name']))
														{
														?>
                                                        <li><a href="myaccount.php">My Account</a></li>
                                                        
                                                        
														<li><a href="logout.php">logout</a></li>
														<?php }
														
														else
														{
															?>
															<li><a href="login.php">Log In and Registration</a></li>
														<?php } ?>
														
                                                        
                                                    </ul>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--Header Option End--> 
                            </div>
                            <!--Header Menu And Mini Cart End-->
                        </div>
                        <div class="row">
                            <div class="col-12"> 
                                <!--Mobile Menu Area Start-->
                                <div class="mobile-menu d-lg-none"></div>
                                <!--Mobile Menu Area End-->
                            </div>
                        </div>
                    </div>
                </div>
		    </div>
		</header>
		<!--Header Area End-->
