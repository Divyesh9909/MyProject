<?php require_once('../config/connection.php');

if(isset($_GET['id']))
{
	$id=$_GET['id'];
	
	$sql="delete from datatables_cart where id='".$id."'";
	
	
	//$result=mysqli_query($conn,$sql);
	if ($conn->query($sql) === TRUE) {
	  echo "New Subject Added successfully";
	  //header("Location:cart.php?msg=success");
	} else {
	  echo "Error: " . $sql . "<br>" . $conn->error;
	  //header("Location:cart.php?msg=failure");
	}
	if($result)
	{
		header("Location:cart.php?msg=success");
	}
	else
	{
		header("Location:cart.php?msg=failure");
	}
	
}

?>