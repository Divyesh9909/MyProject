<?php include("header_pages.php");?>
<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Privacy & Policy</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">home</a></li>
                                <li class="active">Privacy & Policy</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<center>
		
		<h4>Privacy Policy</h4>

<P>This privacy policy sets out how Greenthrives uses and protects any information that you give Greentrhives when you use this website.

Greentrhives is committed to ensuring that your privacy is protected. Should we ask you to provide certain information by which you can be identified when using this website, then you can be assured that it will only be used in accordance with this privacy statement.

Greentrhives may change this policy from time to time by updating this page. You should check this page from time to time to ensure that you are happy with any changes.</P>
<br>
<br>
<h4>Security</h4>
<p>We are committed to ensuring that your information is secure. In order to prevent unauthorized access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.</p>
<br>
<br>
<h4>Controlling your personal Information</h4>
<p>You may choose to restrict the collection or use of your personal information in the following ways:

whenever you are asked to fill in a form on the website, look for the box that you can click to indicate that you do not want the information to be used by anybody for direct marketing purposes

if you have previously agreed to us using your personal information for direct marketing purposes, you may change your mind at any time by writing to or emailing us at care@Greentrhives.com

We will not sell, distribute or lease your personal information to third parties unless we have your permission or are required by law to do so. We may use your personal information to send you promotional information about third parties which we think you may find interesting if you tell us that you wish this to happen.

 A small fee will be payable. If you would like a copy of the information held on you please write to care@Greentrhives.com

 

If you believe that any information we are holding on you is incorrect or incomplete, please write to or email us as soon as possible, at the above address. We will promptly correct any information found to be incorrect.</p>

<?php include("footer.php");?>