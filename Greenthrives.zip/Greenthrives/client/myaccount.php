<?php include("header_pages.php");?>
<?php
require_once('../config/connection.php');


	$id=$_SESSION['u_id'];

	$sql="select * from datatables_user where id='".$id."'";
	
    $result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($result);

?>

<?php
						if ($_SERVER["REQUEST_METHOD"] =="POST")
						{
							if (isset($_POST["name"]) &&  isset($_POST["email"]) && isset($_POST["gender"]) && isset($_POST["contact"]) && isset($_POST["dob"]))
							{ 
								$name=$_POST["name"];
								
								$email=$_POST["email"];
								
								$contact=$_POST["contact"];
								
								$gender=$_POST["gender"];	
								$dob=$_POST["dob"];
										   
								if($name!=''  && $email!='' && $contact!='' &&
								 $gender!='' && $dob!='')
								{
									$sql2 = "update datatables_user set user_name='".$name."', email='".$email."',
									contact='".$contact."', gender='".$gender."',
									dob='".$dob."' where id='".$id."'";
									
									
									
									$result2=mysqli_query($conn,$sql2);
											   
									if($result2)
									{
										echo "<meta http-equiv='refresh' content='3;url=home.php'>";
									}
								}
								else
								{
										echo "hello";
								}
							}
							  
						}
					?>									
                                 
 
 
 <?php
						if ($_SERVER["REQUEST_METHOD"] =="POST")
						{
							if (isset($_POST["number"]) &&  isset($_POST["name"]) && isset($_POST["landmark"]) && isset($_POST["city"]) && isset($_POST["type"]))
							{ 	
								$id=$_SESSION['u_id'];
								$name=$_POST["name"];
								
								$number=$_POST["number"];
								
								$landmark=$_POST["landmark"];
								
								$city=$_POST["city"];	
								$type=$_POST["type"];
										   
								if($number!=''  && $name!='' && $landmark!='' &&
								 $city!='' && $type!='')
								{
									$sql3 = "insert into datatables_address(house_no,building_name,landmark,city,address_type,user_id_id)
											values('".$number."','".$name."','".$landmark."','".$city."','".$type."','".$id."')";									
									
									
									$result3=mysqli_query($conn,$sql3);
											   
									if($result3)
									{
										echo "<meta http-equiv='refresh' content='3;url=home.php'>";
									}
								}
								else
								{
										echo "hello";
								}
							}
							else
							{
								echo"value not set";
							}	   
						}
					?>									
                                 

		
		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>My Account</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">My Account</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--My Account Area Strat-->
		<div class="my-account white-bg mb-110">
            <div class="container">
                <div class="account-dashboard">
                   
                    <div class="row">
                        <div class="col-md-12 col-lg-2">
                            <!-- Nav tabs -->
                            <ul class="nav flex-column dashboard-list" role="tablist">
                                
                                
                                <li><a class="nav-link" data-toggle="tab" href="#address">Addresses</a></li>
                                <li><a class="nav-link" data-toggle="tab" href="#account-details">Account details</a></li>
                                <li><a class="nav-link" href="logout.php">logout</a></li>
                            </ul>
                        </div>
                        <div class="col-md-12 col-lg-10">
                            <!-- Tab panes -->
                            <div class="tab-content dashboard-content">
                                
                                
                                
                                <div id="address" class="tab-pane fade">
                                    <h3>Address </h3>
                                    <div class="login">
                                        <div class="login-form-container">
                                            <div class="account-login-form">
                                                <form action="#" method="post">
                                                    
                                                    
                                                    <label>House Number</label>
                                                    <input name="number" type="text">
                                                    
                                                    <label>Building Name</label>
                                                    <input name="name" type="text">
													<label>Landmark</label>
                                                    <input name="landmark" type="text">
                                                    <label>City</label>
                                                    <input name="city" type="text">
                                                    <label>Address Type</label>
                                                    <input name="type" type="text">
                                                    
                                                    
                                                   
                                                    <div class="button-box">
                                                        <button type="submit" class="default-btn">save</button>
                                                    </div>
                                                </form>
                                            </div> 
                                        </div>
		                            </div>
                                </div>
                                <div id="account-details" class="tab-pane fade">
                                    <h3>Account details </h3>
                                    <div class="login">
                                        <div class="login-form-container">
                                            <div class="account-login-form">
                                                <form action="#" method="post">
                                                    
                                                    
                                                    <label>User Name</label>
                                                    <input name="name" type="text" value=<?php echo $row['user_name'];?>>
                                                    
                                                    <label>Email</label>
                                                    <input name="email" type="email" value=<?php echo $row['email'];?>>
													<label>Contact Number</label>
                                                    <input name="contact" type="text" value=<?php echo $row['contact'];?>>
                                                    <label>Gender</label>
                                                    <input name="gender" type="text" value=<?php echo $row['gender'];?>>
                                                    <label>DOB</label>
                                                    <input name="dob" value=<?php echo $row['dob'];?> placeholder="YYYY/MM/DD" type="text">
                                                    
                                                    
                                                   
                                                    <div class="button-box">
                                                        <button type="submit" class="default-btn">save</button>
                                                    </div>
                                                </form>
                                            </div> 
                                        </div>
		                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
        <!--My Account Area End-->
		<?php include("footer.php");?>