<footer>
		    <div class="footer-container">
		        <!--Footer Top Area Start-->
		        <div class="footer-top-area black-bg">
		            <div class="container">
		                <div class="row">
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-40">
		                            <div class="footer-title">
		                                <h3>Stay in Touch</h3>
		                            </div>
		                            <ul class="link-widget">
		                                <li><a href="#">For any suggestions, queries, complaints etc </a></li>
		                                <br>
										<li><a href="#">Email : care@greenthrives.com</a></li>
		                                
		                            </ul>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-40">
		                            <div class="footer-title">
		                                <h3>Information</h3>
		                            </div>
		                            <ul class="link-widget">
		                                <li><a href="aboutus.php">About Us</a></li>
										<br>
										<?php
										if(isset($_SESSION['u_name']))
										{
											?>
		                                
										<li><a href="contactus.php">Contact Us</a></li>
										<?php } ?>
		                                <br>
										<li><a href="privacy.php">Privacy Policy</a></li>
		                            </ul>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-40">
		                            <div class="footer-title">
		                                <h3>Quick Links</h3>
		                            </div>
		                            <ul class="link-widget">
		                                <li><a href="home.php">Home</a></li>
		                                <li><a href="aboutus.php">About us</a></li>
		                                
		                                <li><a href="privacy.php">Privacy Policy</a></li>
										 
										 <?php
										if(isset($_SESSION['u_name']))
										{
											?>
		                                <li><a href="contactus.php">Contact us</a></li>
										<?php } ?>
		                            </ul>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-40">
		                            <div class="footer-title">
		                                <h3>Categories</h3>
		                            </div>
										<?php
												$category="select * from datatables_category where parent_category_id IS NULL";
												$q=mysqli_query($conn,$category);
									
												while($row=mysqli_fetch_array($q))
												{
													$id=$row['id'];
												?>
												
		                            <ul class="link-widget">
		                                <li><a href="#"><?php echo $row["category_name"];?></a></li>
		                                		                            </ul>
												<?php } ?>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                </div>
		            </div>
		        </div>
		        <!--Footer Top Area End-->
		        <!--Footer Middle Area Start-->
		        <div class="footer-middle-area black-bg">
		            <div class="container">
		                <div class="row">
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-30">
		                            <div class="footer-logo">
		                                <a href="index.html"><img src="img/logo/logo-footer.png" alt=""></a>
		                            </div>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                    
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-30">
		                            <div class="footer-info">
		                                <div class="icon">
		                                    <i class="fa fa-envelope-open-o"></i>
		                                </div>
		                                <p>Email: <br>info@greenthrives.com</p>
		                            </div>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                    <div class="col-lg-3 col-md-6">
		                        <!--Single Footer Widget Start-->
		                        <div class="single-footer-widget mb-30">
		                            <div class="footer-info">
		                                <div class="icon">
		                                    <i class="fa fa-mobile"></i>
		                                </div>
		                                <p>Phone: <br>(+91)9099521090</p>
		                            </div>
		                        </div>
		                        <!--Single Footer Widget End-->
		                    </div>
		                </div>
		            </div>
		        </div>
		        <!--Footer Middle Area End-->
		        <!--Footer Bottom Area Start-->
		        <div class="footer-bottom-area black-bg pt-50 pb-50">
		            <div class="container">
		                <div class="row">
		                    <div class="col-md-12">
                                
		                        <!--Footer Menu Start-->
		                        
		                        <!--Footer Menu End-->
		                        <!--Footer Copyright Start-->
		                        <div class="footer-copyright">
									<p class="copyright">&copy; 2021 <strong>Greenthrives</strong> Made with <i class="fa fa-heart text-danger" aria-hidden="true"></i>.</p>
		                        </div>
		                        <!--Footer Copyright End-->
		                    </div>
		                </div>
		            </div>
		        </div>
		        <!--Footer Bottom Area End-->
		    </div>
		</footer>
		<!--Footer Area End-->
		<!-- Modal Area Strat -->
        <div class="modal fade" id="open-modal" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
              </div>
              <div class="modal-body">
                <div class="row">
                    <!--Modal Img-->
                    <div class="col-md-5">
                        <!--Modal Tab Content Start-->
                        <div class="tab-content product-details-large" id="myTabContent">
                          <div class="tab-pane fade show active" id="single-slide1" role="tabpanel" aria-labelledby="single-slide-tab-1">
                              <!--Single Product Image Start-->
                              <div class="single-product-img img-full">
                                <img src="img/single-product/large/single-product1.jpg" alt="">
                              </div>
                              <!--Single Product Image End-->
                          </div>
                          <div class="tab-pane fade" id="single-slide2" role="tabpanel" aria-labelledby="single-slide-tab-2">
                              <!--Single Product Image Start-->
                              <div class="single-product-img img-full">
                                <img src="img/single-product/large/single-product2.jpg" alt="">
                              </div>
                              <!--Single Product Image End-->
                          </div>
                          <div class="tab-pane fade" id="single-slide3" role="tabpanel" aria-labelledby="single-slide-tab-3">
                              <!--Single Product Image Start-->
                              <div class="single-product-img img-full">
                                <img src="img/single-product/large/single-product3.jpg" alt="">
                              </div>
                              <!--Single Product Image End-->
                          </div>
                          <div class="tab-pane fade" id="single-slide4" role="tabpanel" aria-labelledby="single-slide-tab-4">
                              <!--Single Product Image Start-->
                              <div class="single-product-img img-full">
                                <img src="img/single-product/large/single-product4.jpg" alt="">
                              </div>
                              <!--Single Product Image End-->
                          </div>
                          <div class="tab-pane fade" id="single-slide5" role="tabpanel" aria-labelledby="single-slide-tab-4">
                              <!--Single Product Image Start-->
                              <div class="single-product-img img-full">
                                <img src="img/single-product/large/single-product5.jpg" alt="">
                              </div>
                              <!--Single Product Image End-->
                          </div>
                          <div class="tab-pane fade" id="single-slide6" role="tabpanel" aria-labelledby="single-slide-tab-4">
                              <!--Single Product Image Start-->
                              <div class="single-product-img img-full">
                                <img src="img/single-product/large/single-product6.jpg" alt="">
                              </div>
                              <!--Single Product Image End-->
                          </div>
                        </div>
                        <!--Modal Content End-->
                        <!--Modal Tab Menu Start-->
                        <div class="single-product-menu">
                            <div class="nav single-slide-menu owl-carousel" role="tablist">
                                <div class="single-tab-menu img-full">
                                    <a class="active" data-toggle="tab" id="single-slide-tab-1" href="#single-slide1"><img src="img/single-product/small/single-product1.jpg" alt=""></a>
                                </div>
                                <div class="single-tab-menu img-full">
                                    <a data-toggle="tab" id="single-slide-tab-2" href="#single-slide2"><img src="img/single-product/small/single-product2.jpg" alt=""></a>
                                </div>
                                <div class="single-tab-menu img-full">
                                    <a data-toggle="tab" id="single-slide-tab-3" href="#single-slide3"><img src="img/single-product/small/single-product3.jpg" alt=""></a>
                                </div>
                                <div class="single-tab-menu img-full">
                                    <a data-toggle="tab" id="single-slide-tab-4" href="#single-slide4"><img src="img/single-product/small/single-product4.jpg" alt=""></a>
                                </div>
                                <div class="single-tab-menu img-full">
                                    <a data-toggle="tab" id="single-slide-tab-5" href="#single-slide5"><img src="img/single-product/small/single-product5.jpg" alt=""></a>
                                </div>
                                <div class="single-tab-menu img-full">
                                    <a data-toggle="tab" id="single-slide-tab-6" href="#single-slide6"><img src="img/single-product/small/single-product6.jpg" alt=""></a>
                                </div>
                            </div>
                        </div>
                        <!--Modal Tab Menu End-->
                    </div>
                    <!--Modal Img-->
                    <!--Modal Content-->
                    <div class="col-md-7">
                        <div class="modal-product-info">
                            <h1>Sit voluptatem</h1>
                            <div class="modal-product-price">
                               <span class="old-price">$74.00</span>
                               <span class="new-price">$69.00</span>
                           </div>
                           <a href="single-product.html" class="see-all">See all features</a>
                           <div class="add-to-cart quantity">
                                <form class="add-quantity" action="#">
                                     <div class="modal-quantity">
                                         <input type="number" value="1">
                                     </div>
                                    <div class="add-to-link">
                                        <button class="form-button" data-text="add to cart">add to cart</button>
                                    </div>
                                </form>
                           </div>
                           <div class="cart-description">
                               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco,Proin lectus ipsum, gravida et mattis vulputate, tristique ut lectus.</p>
                           </div>
                            <div class="social-share">
                               <h3>Share this product</h3>
                               <ul class="socil-icon2">
                                   <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                   <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                   <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                   <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                   <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                               </ul>
                            </div>
                        </div>
                    </div>
                    <!--Modal Content-->
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Modal Area End -->
	</div>





    <!--All Js Here-->
    
	<!--Jquery 1.12.4-->
	<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<!--Popper-->
	<script src="js/popper.min.js"></script>
	<!--Bootstrap-->
	<script src="js/bootstrap.min.js"></script>
	<!--Imagesloaded-->
	<script src="js/imagesloaded.pkgd.min.js"></script> 
	<!--Isotope-->
	<script src="js/isotope.pkgd.min.js"></script>
	<!--Waypoints-->
	<script src="js/waypoints.min.js"></script>
	<!--Counterup-->
	<script src="js/jquery.counterup.min.js"></script>
	<!--Carousel-->
	<script src="js/owl.carousel.min.js"></script>
	<!--Slick-->
	<script src="js/slick.min.js"></script>
	<!--Meanmenu-->
	<script src="js/jquery.meanmenu.min.js"></script>
	<!--Easyzoom-->
	<script src="js/easyzoom.min.js"></script>
	<!--Nice Select-->
	<script src="js/jquery.nice-select.min.js"></script>
	<!--ScrollUp-->
	<script src="js/jquery.scrollUp.min.js"></script>
	<!--Wow-->
	<script src="js/wow.min.js"></script>
	<!--Venobox-->
	<script src="js/venobox.min.js"></script>
	<!--Jquery Ui-->
	<script src="js/jquery-ui.js"></script>
	<!--Countdown-->
	<script src="js/jquery.countdown.min.js"></script>
	<!--Plugins-->
	<script src="js/plugins.js"></script>
	<!--Main Js-->
	<script src="js/main.js"></script>
</body>

<!-- Mirrored from demo.hasthemes.com/plantmore-preview/plantmore-v5/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Mar 2021 11:59:44 GMT -->
</html>
