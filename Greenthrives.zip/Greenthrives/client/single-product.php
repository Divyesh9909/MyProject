<?php include("header_pages.php");?>
<?php
require_once('../config/connection.php');
if(isset($_GET['id']))
{
	$id=$_GET['id'];
	$sql="select * from datatables_product p JOIN datatables_category c JOIN datatables_gallary g 
	JOIN datatables_product_details pd  where p.category_id_id=c.id and p.id=g.product_id_id
	and p.id=pd.product_id_id  AND p.id='".$id."'";
	
	
	
    $result=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($result);
	
	
}
?>
<?php 
if(isset($_POST['cart']))
{
if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$qty=$_POST['qty'];
	echo"<meta http-equiv='refresh'
	content='0;url=insertcart.php?pid=$id&qty=$qty'>";
}
}
									
					
					
?>
		<!--Breadcrumb One Start-->
		<div class="breadcrumb-one mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-img">
                            <img src="img/page-banner/product-banner.jpg" alt="">
                        </div>
                        <div class="breadcrumb-content">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">Single Product</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb One End-->
		
		<!--Single Product Area Start-->
		<div class="single-product-area mb-115">
		    <div class="container">
		        <div class="row">
		            <div class="col-md-12 col-lg-5">
		                <div class="product-details-img-tab">
		                    <!--Product Tab Content Start-->
		                    <div class="tab-content single-product-img">
                              <div class="tab-pane fade show active" id="product1">
                                  <div class="product-large-thumb img-full">
										
									
                                     <div class="easyzoom easyzoom--overlay">
                                        <a href="../gallary/<?php echo $row['gallary_path']?>">
                                            <img src="../gallary/<?php echo $row['gallary_path']?>" alt="">
                                        </a>
                                        <a href="../gallary/<?php echo $row['gallary_path']?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a>
                                     </div>
									
                                  </div>
                              </div>
                              
                              
                              
                              
                              
                            </div>
		                    <!--Product Tab Content End-->
		                    		                    <!--Product Tab Menu Start-->
		                    <div class="product-menu">
		                        <div class="nav product-tab-menu">
									<?php
									$img="select * from datatables_gallary where product_id_id=$id";
									$q=mysqli_query($conn,$img);
									
											while($row3=mysqli_fetch_array($q))
									{
										
									?>  
                                  <div class="product-details-img">
                                    <a class="active" data-toggle="tab" href="#product1"><img src="../gallary/<?php echo $row3['gallary_path']?>" alt=""></a>
                                  </div>
									<?php } ?>
                                  
                                  
                                  
                                  
                                </div>
		                    </div>
		                    <!--Product Tab Menu End-->
		                </div>
		            </div>
		            <div class="col-md-12 col-lg-7">
                        <!--Product Details Content Start-->
		                <div class="product-details-content">
                            <!--Product Nav Start-->
                            <div class="product-nav">
                                <a href="single-product.php?id=<?php echo $id?>"><i class="fa fa-angle-left"></i></a>
                                <a href="single-product.php?id=<?php echo $id?>"><i class="fa fa-angle-right"></i></a>
                            </div>
                            <!--Product Nav End-->
		                    <h2><?php echo $row['product_name']?></h2>
		                    
                            <div class="single-product-price">
                                
                                <span class="regular-price"><?php echo $row['product_price']?></span>
                            </div>
                            <div class="product-description">
                                <p><?php echo $row['product_description']?></p>
                            </div>
                            
                            <div class="single-product-quantity">
								<?php
														if(isset($_SESSION['u_name']))
														{
														?>
                                <form class="add-quantity" action="#" method="post">
                                     <div class="product-quantity">
                                         <input  name="qty" value="1" type="number">
                                     </div>
									 
                                    <div class="add-to-link">
                                        <button class="product-btn" data-text="add to cart" name="cart">add to cart</button>
                                    </div>
                                </form>
														<?php } else {
															?>
															<?php echo "<h3>Please login or Register to buy products from us</h3>";?>
						
														<?php } ?>
                           </div>
                            
                            
                            
		                </div>
		                <!--Product Details Content End-->
		            </div>
		        </div>
		    </div>
		</div>
		<!--Single Product Area End-->
	
		<!--Product Description Review Area Start-->
		<div class="product-description-review-area mb-100">
		    <div class="container">
		        <div class="row">
		            <div class="col-md-12">
		                <div class="product-review-tab">
		                    <!--Review And Description Tab Menu Start-->
		                    <ul class="nav dec-and-review-menu">
                              <li>
                                <a class="active" data-toggle="tab" href="#description">Description</a>
                              </li>
                              
                            </ul>
		                    <!--Review And Description Tab Menu End-->
		                    <!--Review And Description Tab Content Start-->
		                    <div class="tab-content product-review-content-tab" id="myTabContent-4">
                              <div class="tab-pane fade active show" id="description">
                                  <div class="single-product-description">
                                     <p><?php echo $row['product_description']?></p>
                                  </div>
                              </div>
                              
                            </div>
		                    <!--Review And Description Tab Content End-->
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Product Description Review Area Start-->
		
		<?php include("footer.php");?>