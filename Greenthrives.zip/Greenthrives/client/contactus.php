<?php include("header_pages.php");?>
<script src="jquery-3.4.1.js" type="text/javascript"></script>
<?php 

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	if(isset($_POST["subject_id_id"]) && isset($_POST["help_desc"])) 
	{
		
		$sid=$_POST["subject_id_id"];
		$date=date("Y/m/d");
		$uid=$_SESSION['u_id'];
		$desc=$_POST["help_desc"];
		
		$file_name=$_FILES['image']['name'];
		$file_tmp=$_FILES['image']['tmp_name'];
		//$file_size=$_FILES['product_image1']['size'];
	
		if( $desc!="" && $file_name!=''
		&& move_uploaded_file($file_tmp,"../gallary/".$file_name)==1)
		{
			
		
			$sql="insert into datatables_helps(help_desc,help_date,subject_id_id,user_id_id,help_image1)
			values('".$desc."','".$date."','".$sid."','".$uid."','".$file_name."')";
			
			
			
			
			$result=mysqli_query($conn,$sql);
			
			if($result)
			{
				echo "<meta http-equiv='refresh' content='0;url=home.php'/>";
			}
		}
		else
		{
			echo "not null";
		}
			
				}
						
				}
			
		
		
	


 
 ?>
	
		<!--Breadcrumb Tow Start-->
		<form method="POST" action="" enctype="multipart/form-data">
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Contact Us</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">Contact Us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Login Register Area Strat-->
		<div class="login-register-area mb-80">
		    <div class="container">
		        <div class="row">
                    <!--Login Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register">
		                    <div class="form-login-title">
		                        <h2>Contact Us</h2>
		                    </div>
		                    <div class="login-form">
		                        <form action="#" method="post">
									
									<script>
									function loadFile(event){
										document.getElementById('output').src=
										URL.createObjectURL(event.target.files[0]);
									};
									</script>
										
										
										
                                    <div class="form-group row">
                                        <label class="col-md-3 col-form-label" for="l16">Help Image</label>
                                        <div class="col-md-9">
                                            <input id="l16"  name= "image" accept="image/*" onchange="loadFile(event)" type="file">
											
                                             
                                        </div>
                                    </div>
									
									
									
								 		  <div class="form-group row">
                                        <label class="col-md-3 col-form-label" for="l13">Help Subject</label>
                                        <div class="col-md-9">
                                            <select class="form-control" id="l13" name="subject_id_id">
                                               <?php
											   $sql4="select * from datatables_help_subject";
											   $result4=mysqli_query($conn,$sql4);
											   while($row4=mysqli_fetch_array($result4))
											   {?>
												   <option value="<?php echo $row4["id"]?>"><?php echo $row4["subject_name"]?></option>
											<?php
											   }
?>											   
											</select>
                                    </div>
									</div>
		                            
									<div class="form-fild">
		                                <p><label>Description<span class="required">*</span></label></p>
		                                <input name="help_desc" value="" type="text">
		                            </div>
		                            
		                            <div class="login-submit">
		                                <button type="submit" class="form-button">Send</button>
		                                
		                            </div>
		                            
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Login Form End-->
		            
		        </div> 
		    </div>
		</div>
		<!--Login Register Area End-->
		<?php include("footer.php");?>