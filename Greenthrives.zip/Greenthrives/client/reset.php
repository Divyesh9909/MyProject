<?php include("header_pages.php")?>
<?php 

require_once('../config/connection.php');
if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$id=$_SESSION['id'];
	$otp=$_POST['otp'];
	$new=$_POST['new'];
	$confirm=$_POST['confirm'];
	
	if($new!=$confirm)
	{
		echo "password must be same";
		exit;
	}
	$query="update datatables_user set otpused=1,password='".$new."' where email='".$id."' and OTP='".$otp."'";
	
	$result=mysqli_query($conn,$query);
	if($result)
	{
		echo "<script>
				alert('password successfully reset');
				window.location='login.php';
				</script>";
	}
}
?>

		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Forgot Password</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="">Home</a></li>
                                <li class="active">Forgot Password</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Login Register Area Strat-->
		<div class="login-register-area mb-80">
		    <div class="container">
		        <div class="row">
                    <!--Login Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register">
		                    <div class="form-login-title">
		                        <h2>Login</h2>
		                    </div>
		                    <div class="login-form" >
		                        <form action="#" method="post">
		                            
									<div class="form-fild">
		                                <p><label>Enter OTP<span class="required">*</span></label></p>
		                                <input name="otp"  value="" type="text">
		                            </div>
		                            <div class="form-fild">
		                                <p><label>New Password <span class="required">*</span></label></p>
		                                <input name="new"  value="" type="password">
		                            </div>
									<div class="form-fild">
		                                <p><label>Confirm New Password <span class="required">*</span></label></p>
		                                <input name="confirm"  value="" type="password">
		                            </div>
									<div class="login-submit">
		                                <button type="submit" name="login" class="form-button">Login</button>
		                                
		                            </div>
		                           
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Login Form End-->
		            
		        </div> 
		    </div>
		</div>
		<!--Login Register Area End-->
<?php include("footer.php");?>
