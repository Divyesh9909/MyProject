<?php 
require_once('../config/connection.php');
include("header_pages.php");

require_once("lib/function.php");
include('PHPMailer/PHPMailerAutoload.php');


if ($_SERVER["REQUEST_METHOD"]=="POST") 
{
	
	
	if(isset($_POST['email']) && !empty($_POST['email']))
	{
		
		$username = mysqli_real_escape_string($conn,$_POST['email']);
		
		$query = "select * from datatables_user where email = '".$username."'";
		
		$result = mysqli_query($conn, $query);
		
		if (mysqli_num_rows($result) == 1) {
		
			$arr = array();
			
				$row=mysqli_fetch_array($result);
				
				$to = $row['email'];
				$arr = $row	;
				
			$otp = mt_rand(000000,999999);
			$query1 = "update datatables_user set OTP = ".$otp.", otpused = 0 where
			
			email = '".$to."'";
	
			$result1 = mysqli_query($conn,$query1);
			
			if ($result1) {
				$message = "<h3>Your new OTP is ".$otp.". Please do not share</h3>";
				$subject = "Request For OTP";		
				$mailSent = send_mail($to, $message, $subject);
				
				if ($mailSent) {
					session_start();
					$_SESSION['id'] = $to;
					echo "<script>
								window.location='reset.php';
					      </script>";
				} else {
					
				}
				$array = array('status' => '200' , 'details' => $arr);
			}	
			
		}	
		
	} 
		 
}

?>


		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Forgot Password</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="">Home</a></li>
                                <li class="active">Forgot Password</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Login Register Area Strat-->
		<div class="login-register-area mb-80">
		    <div class="container">
		        <div class="row">
                    <!--Login Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register">
		                    <div class="form-login-title">
		                        <h2></h2>
		                    </div>
		                    <div class="login-form" >
		                        <form action="#" method="post">
		                            
									<div class="form-fild">
		                                <p><label>Email address <span class="required">*</span></label></p>
		                                <input name="email"  value="" type="email">
		                            </div>
		                            
									<div class="login-submit">
		                                <button type="submit" name="login" class="form-button">Login</button>
		                                
		                            </div>
		                            
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Login Form End-->
		            
		        </div> 
		    </div>
		</div>
		<!--Login Register Area End-->
<?php include("footer.php");?>


