<?php include("header_pages.php");
if(isset($_GET['cid']))
{
	$oid = $_GET['cid'];
	$sql="update datatables_order set payment_status=1 where id = $oid";
	$r = mysqli_query($conn,$sql);
}

?>

		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>My Orders</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="home.php">Home</a></li>
                                <li class="active">My Orders</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Shopping Cart Area Strat-->
		<div class="Shopping-cart-area mb-110">
		    <div class="container">
		        <div class="row">
		            <div class="col-12">
		                <form action="#">
		                    <div class="table-content table-responsive">
		                        <table class="table">
		                            <thead>
		                                <tr>
		                                    
		                                    <th class="plantmore-product-thumbnail">Product Name</th>
		                                    <th class="cart-product-name">Quantity</th>
		                                    <th class="plantmore-product-price">Amount</th>
		                                    
		                                   
		                                </tr>
		                            </thead>
		                            <tbody>
										<?php
							
									$id = $_GET['id'];
									$sql="select * from datatables_orderdetails od JOIN datatables_order o JOIN datatables_product p 
									JOIN datatables_cart c where od.order_id_id=o.id and od.product_id_id=p.id and od.product_id_id=c.product_id_id and o.id=$id";
									
							
								
									$result=mysqli_query($conn,$sql);

										while($row=mysqli_fetch_array($result))
										{ 
										?>
		                                 <tr>
                                
                                
                                
											<td class="pro-price"><span><?php echo $row['product_name']?></span></td>
											<td class="pro-price"><span><?php echo $row['qty']?></span></td>
											<td class="pro-price"><span><?php echo $row['amount']?></span></td>
								
                               
                              
                                
										</tr>
										<?php } ?>
		                                
		                            </tbody>
		                        </table>
		                    </div>
		                    
		                    
		                </form>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Shopping Cart Area End-->
	<?php include("footer.php");?>