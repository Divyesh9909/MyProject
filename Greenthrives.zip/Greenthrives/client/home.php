<?php include("header.php");
require_once("lib/function.php");
include('PHPMailer/PHPMailerAutoload.php');?>
<?php
require_once('../config/connection.php');?>

<?php
if(isset($_SESSION['u_name']))
{
$uid=$_SESSION['u_id'];
}
$query="select * from datatables_product p JOIN datatables_category c 
JOIN datatables_product_details pd where p.category_id_id=c.id and
p.id=pd.product_id_id AND pd.product_date='".date("Y/m/d")."'"; 

$result1=mysqli_query($conn,$query);




$sql3="select * from datatables_product p JOIN datatables_category c  
	 JOIN datatables_product_details pd where p.category_id_id=c.id and
	p.id=pd.product_id_id ";
$result3 = mysqli_query($conn,$sql3);




$sql="select * from datatables_feedback f JOIN datatables_order o JOIN datatables_user u where f.order_id_id=o.id and o.user_id_id=u.id";
$result=mysqli_query($conn,$sql);
if(isset($_SESSION['u_name']))
{
$sql2="select * from datatables_helps h JOIN  datatables_help_subject hs where h.subject_id_id=hs.id and h.user_id_id=$uid";
$result2=mysqli_query($conn,$sql2);
}
?>

		
		
		<!--Slider Area Start-->
		<div class="slider-area">
		    <div class="hero-slider owl-carousel">
		        <!--Single Slider Start-->
		        <div class="single-slider" style="background-image: url(img/slider/home1-slider1.jpg)">   
                    <div class="slider-progress"></div>
		            <div class="container">
		                <div class="hero-slider-content">
		                    <h1>Get Your <br>Perfect Plant</h1>
		                    <div class="slider-border"></div>
		                    <p>Stay in touch with us We help you grow your garden for lifetime.And we will provide our best efforts to solve your queries.</p>
		                    <?php if(isset($_SESSION['u_name']))
							{
								$uid=$_SESSION['u_id'];
						?>
							<div class="slider-btn">
		                        <a href="contactus.php">Contact Us <i class="fa fa-chevron-right"></i></a>
		                    </div>
							<?php }?>
		                </div>
		            </div>
		        </div>
		        <!--Single Slider End-->
		        <!--Single Slider Start-->
		        <div class="single-slider" style="background-image: url(img/slider/home1-slider2.jpg)">   
                    <div class="slider-progress"></div>
		            <div class="container">
		                <div class="hero-slider-content">
		                    <h1>Get your <br>Trendy Plant.</h1>
		                    <div class="slider-border"></div>
		                    <p>Diligent care taken to deliver healthy  plants.</p>
		                    <div class="slider-btn">
		                        <a href="aboutus.php">Get to know About US <i class="fa fa-chevron-right"></i></a>
		                    </div>
		                </div>
		            </div>
		        </div>
		        <!--Single Slider End-->
		    </div>
		</div>
		<!--Slider Area End-->
		
		<!--Product Area Start-->
		<div class="product-area mt-85">
		    <div class="container">
		        <div class="row">
		            <!--Section Title Start-->
		            <div class="col-12">
		                <div class="section-title text-center mb-35">
		                    <span>The Most Trendy</span>
		                    <h3>Featured Products</h3>
		                </div>
		            </div>
		            <!--Section Title End-->
		        </div>
		        <div class="row">
		            <div class="product-slider-active">
		                
							<?php
						while($row=mysqli_fetch_assoc($result3))
						{
							?>
							<div class="col-md-3 col-lg-3 col-sm-4 col-xs-12">
							<?php
							$product_id = $row['product_id_id'];
							$query_images = "SELECT * FROM datatables_gallary WHERE product_id_id = {$product_id} LIMIT 1";
							
							$result_gallary = mysqli_query($conn,$query_images);
							while($gallary_row=mysqli_fetch_assoc($result_gallary))
							{
								
								?>
								<div class="single-product mb-25">					
									<div class="product-img img-full">
										<a href="single-product.php?id=<?php echo $product_id?>&sid=<?php echo $id?>">
											<img src="../gallary/<?php echo $gallary_row['gallary_path']?>" alt="">
										</a>
									</div>
									
									<div class="product-content">
										<h2><a href="single-product.php?id=<?php echo $product_id?>&sid=<?php echo $id?>"><?php echo $row['product_name']?></a></h2>
										<div class="product-price">
											<div class="price-box">
												<span class="regular-price">&#8377;<?php echo $row['product_price']?></span>
											</div>
											
										</div>
									</div>
								</div>
								<?php
							}?>
							</div>
							<?php
						}
						?>
		                    <!--Single Product End-->
						
		                
		                
		                
		                
		                
		                
		            
		        </div>
		    </div>
		</div>
		<!--Product Area End-->
		<?php
		if(isset($_SESSION['u_name']))
		{
					?>
		<!--Testimonial Area Start-->
		<div class="testimonial-area mt-75">
		    <div class="container">
		        <div class="row">
		            <!--Section Title Start-->
		            <div class="col-12">
		                <div class="section-title text-center mb-35">
		                    <span>We love to Solve</span>
		                    <h3>the Queries from the Clients</h3>
		                </div>
		            </div>
		            <!--Section Title End-->
		        </div>
				
							 <?php 		while($row2=mysqli_fetch_array($result2))
 
							{?>
		        <div class="row testimonial-active owl-carousel">
		            <div class="col-12">
		                <!--Single Testimonial Start-->
		                <div class="single-testimonial text-center">
                            
                            <div class="testimonial-content">
                                <p><?php echo $row2['help_response']?></p>
								<br>
								
								<h4><p><b>Subject :</b><?php echo $row2['subject_name']?></p></h4>
                                <div class="testimonial-author">
                                    <h6><span></span></h6>
                                </div>
                            </div>
					
                        </div>
		                <!--Single Testimonial End-->
		            </div>
					
		           
		           
		        </div>
				<?php } ?>
		    </div>
		</div>
		<!--Testimonial Area End-->
		<?php } ?>
		<!--Product Countdown Area Start-->
		<div class="product-countdown-area mt-105 ml-50 mr-50">
		    <div class="container">
		        <div class="row">
		            <!--Section Title Start-->
		            <div class="col-12">
		                <div class="section-title text-center mb-30">
		                    <h3>New Arrivals</h3>
		                </div>
		            </div>
		            <!--Section Title End-->
		        </div>
		        
		        <div class="row">
		            <div class="offer-slider">
		               
							<?php
						while($row=mysqli_fetch_assoc($result1))
						{
							?>
							 <div class="col-md-4">
							<?php
							$product_id = $row['product_id_id'];
							$query_images = "SELECT * FROM datatables_gallary WHERE product_id_id = {$product_id} LIMIT 1";
							$result_gallary1 = mysqli_query($conn,$query_images);
							while($gallary_row=mysqli_fetch_assoc($result_gallary1))
							{
								
								?>
								<div class="single-product mb-25">					
									<div class="product-img img-full">
										<a href="single-product.php?id=<?php echo $product_id?>&sid=<?php echo $id?>">
											<img src="../gallary/<?php echo $gallary_row['gallary_path']?>" alt="">
										</a>
									</div>
									
									<div class="product-content">
										<h2><a href="single-product.php?id=<?php echo $product_id?>&sid=<?php echo $id?>"><?php echo $row['product_name']?></a></h2>
										<div class="product-price">
											<div class="price-box">
												<span class="regular-price">&#8377;<?php echo $row['product_price']?></span>
											</div>
											
										</div>
									</div>
								</div>
								<?php
							}?>
							</div>
							<?php
						}
						?>

		            </div>
		        </div>
		    </div>
		</div>
		<!--Product Countdown Area End-->
		<!--Banner Area Start-->
		<div class="banner-area pt-105">
		    <div class="container-fluid pl-50 pr-50">
		        <div class="row">
		            <div class="col-md-4">
		                <!--Single Banner Area Start-->
		                <div class="single-banner mb-35">
		                    <div class="banner-img">
		                        <a href="#">
		                            <img src="img/banner/banner1.jpg" alt="">
		                        </a>
		                    </div>
		                </div>
		                <!--Single Banner Area End-->
		            </div>
		            <div class="col-md-4">
		                <!--Single Banner Area Start-->
		                <div class="single-banner mb-35">
		                    <div class="banner-img">
		                        <a href="#">
		                            <img src="img/banner/banner2.jpg" alt="">
		                        </a>
		                    </div>
		                </div>
		                <!--Single Banner Area End-->
		            </div>
		            <div class="col-md-4">
		                <!--Single Banner Area Start-->
		                <div class="single-banner mb-35">
		                    <div class="banner-img">
		                        <a href="#">
		                            <img src="img/banner/banner3.jpg" alt="">
		                        </a>
		                    </div>
		                </div>
		                <!--Single Banner Area End-->
		            </div>
		        </div>
		    </div>
		</div>
		<!--Banner Area End-->
		<!--Testimonial Area Start-->
		<div class="testimonial-area mt-75">
		    <div class="container">
		        <div class="row">
		            <!--Section Title Start-->
		            <div class="col-12">
		                <div class="section-title text-center mb-35">
		                    <span>We love our clients</span>
		                    <h3>What They’re Saying</h3>
		                </div>
		            </div>
		            <!--Section Title End-->
		        </div>
		        <div class="row testimonial-active owl-carousel">
		             <?php 		while($row=mysqli_fetch_array($result))
 
							{?>
					<div class="col-12">
					
		                <!--Single Testimonial Start-->
		                <div class="single-testimonial text-center">
                            
							
                            <div class="testimonial-content">
                                <p><?php echo $row['feedback_desc']?></p>
								<br>
								
								<h4><p><b>Reply:</b><?php echo $row['feedback_reply']?></p></h4>
                                <div class="testimonial-author">
                                    <h6><?php echo $row['user_name']?><span>Customer</span></h6>
                                </div>
                            </div>
					
                        </div>
		                <!--Single Testimonial End-->
						
						</div>
						<?php } ?>
		           
		           
		        </div>
		    </div>
		</div>
		<!--Testimonial Area End-->
		<!--News Letter Area Start-->
		<div class="news-letter-area mt-120 mb-120">
		    <div class="container">
		        <div class="row">
		            <!--Section Title Start-->
		            <div class="col-12">
		                <div class="section-title text-center mb-35">
		                    <h3>Send Newsletter</h3>
		                </div>
		            </div>
		            <!--Section Title End-->
		        </div>
				<?php
				if($_SERVER['REQUEST_METHOD']=='POST')
				{
				
				if(isset($_POST["email"]))
				{
					$email=$_POST["email"];
					
					if($email!='')
					{

					$message="<h3>Thanks for subsbscription</h3>";
					$subject="Subscription";
					$mailSent=send_mail($email,$message,$subject);
					echo "<meta http-equiv='refresh' content='0;home.php'>";
					}
				}
				}
				?>
		        <div class="row">
		            <div class="col-md-12">
		                <div class="news-latter-box">
		                    <p>Enter Your Email Address For Our Mailing List To Keep Your Self Update</p>
		                    <div class="news-letter-form text-center">
		                        <form action="#" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="popup-subscribe-form validate" novalidate>
                                   <div id="mc_embed_signup_scroll">
                                      <div id="mc-form" class="mc-form subscribe-form" >
                                        <input id="mc-email" type="email" name="email" placeholder="Enter your email here" autocomplete="off"/>
                                        <button id="mc-submit" type="submit">Subscribe <i class="fa fa-chevron-right"></i></button>
                                      </div>
                                   </div>
                               </form>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--News Letter Area End-->
		<!--Footer Area Start-->
		<?php include("footer.php");?>