<?php include("header_pages.php");?>
<?php 



require_once('../config/connection.php');


if(isset($_POST['login']))
{

if(isset($_POST["email"])&& isset($_POST["password"]))
{
	$email=$_POST["email"];
	$pwd=$_POST["password"];
	if($email!='' && $pwd!='')
	{
		$sql="select * from datatables_user where email='".$email."' and password='".$pwd."'";
		
		$result=mysqli_query($conn,$sql);
		
		if(mysqli_num_rows($result)==1)
		{
			$row=mysqli_fetch_array($result);
			
			
			$_SESSION['user_name']=$row['id'];
			$_SESSION['u_id']=$row['id'];
			$_SESSION['u_name']=$row['user_name'];
			echo "<meta http-equiv='refresh' content='0;url=home.php'/>";
		}
		else
		{
			$msg="Invalid Username and Password";
		}	
	}
}

}
?>
<?php
if(isset($_POST['register']))
{
if($_SERVER["REQUEST_METHOD"]=="POST")
{
	$user_name=$_POST["user_name"];
	$email=$_POST["email"];
	$password=$_POST["password"];
	$contact=$_POST["contact"];
	$dob=$_POST["dob"];
	$gender=$_POST["gender"];
	if($user_name!=""  && $email!="" && $password!="" && $contact!="" && $dob!="" && $gender!="")
	{
		
		$sql1="insert into datatables_user(user_name,email,password,contact,dob,gender)
		values('".$user_name."','".$email."','".$password."','".$contact."','".$dob."','".$gender."')";
		$result1=mysqli_query($conn,$sql1);
		
		if($result1)
			{
				echo "<meta http-equiv='refresh' content='0;url=login.php'/>";
			}
		}
		else
		{
			echo "null values";
		}
}
}


?>


		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-120">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-title">
                            <h1>Login - Register</h1>
                        </div>
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="index.html">Home</a></li>
                                <li class="active">Login-Register</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Login Register Area Strat-->
		<div class="login-register-area mb-80">
		    <div class="container">
		        <div class="row">
                    <!--Login Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register">
		                    <div class="form-login-title">
		                        <h2>Login</h2>
		                    </div>
		                    <div class="login-form" >
		                        <form action="#" method="post">
		                            
									<div class="form-fild">
		                                <p><label>Email address <span class="required">*</span></label></p>
		                                <input name="email"  value="" type="email">
		                            </div>
		                            <div class="form-fild">
		                                <p><label>Password <span class="required">*</span></label></p>
		                                <input name="password"  value="" type="password">
		                            </div>
									<div class="login-submit">
		                                <button type="submit" name="login" class="form-button">Login</button>
		                                
		                            </div>
		                            <div class="lost-password">
		                                <a href="forgot.php">Lost your password?</a>
		                            </div>
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Login Form End-->
		            <!--Register Form Start-->
		            <div class="col-md-6 col-sm-6">
		                <div class="customer-login-register register-pt-0">
		                    <div class="form-register-title">
		                        <h2>Register</h2>
		                    </div>
		                    <div class="register-form">
		                        <form action="#" method="post">
									<div class="form-fild">
		                                <p><label>Full Name<span class="required">*</span></label></p>
		                                <input name="user_name"  value="" type="text">
		                            </div>
		                            <div class="form-fild">
		                                <p><label>Email address <span class="required">*</span></label></p>
		                                <input name="email" value="" type="email">
		                            </div>
		                            <div class="form-fild">
		                                <p><label>Password <span class="required">*</span></label></p>
		                                <input name="password" value="" type="password">
		                            </div>
									<div class="form-fild">
		                                <p><label>Contact Number<span class="required">*</span></label></p>
		                                <input name="contact"  value="" type="text">
		                            </div>
									<div class="form-fild">
		                                <p><label>Gender<span class="required">*</span></label></p>
		                                <input name="gender" placeholder="M/F" value="" type="text">
		                            </div>
									<div class="form-fild">
		                                <p><label>DOB<span class="required">*</span></label></p>
		                                <input name="dob" placeholder="YYYY-MM-DD"  value="" type="text">
		                            </div>
									
		                            
		                            <div class="register-submit">
		                                <button type="submit" class="form-button" name="register">Register</button>
		                            </div>
		                        </form>
		                    </div>
		                </div>
		            </div>
		            <!--Register Form End-->
		        </div> 
		    </div>
		</div>
		<!--Login Register Area End-->
<?php include("footer.php");?>