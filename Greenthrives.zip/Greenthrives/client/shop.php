<?php include("header_pages.php");?>
		<!--Header Area End-->
		<!--Shop Area Start-->
		<div class="shop-area mb-70">
		    <div class="container">
		        <div class="row">
		            <div class="col-lg-3 order-2 order-lg-1">
		                <!--Product Category Widget Start-->
		                <div class="shop-sidebar">
		                    <h4>Product Categories</h4>
		                    <div class="categori-checkbox">
		                        <form action="#">
									<?php
												$category="select * from datatables_category where parent_category_id IS NULL";
												$q=mysqli_query($conn,$category);
									
												while($row=mysqli_fetch_array($q))
												{
													$id1=$row['id'];
												?>
		                            <ul>
		                                <li><input name="product-categori" type="checkbox"><a href="shop.php?id1=<?php echo $id1?>"><?php echo $row["category_name"];?></a></li>
		                                
		                            </ul>
												<?php }?>
		                        </form>
		                    </div>
		                </div>
		                <!--Product Category Widget End-->
		                <!--Color Category Widget Start-->
						<?php
						
							?>
		                <div class="shop-sidebar">
		                    <h4>Price Filter</h4>
		                    <div class="categori-checkbox">
		                        <form action="#">
		                            <ul>
		                                <li><a href="shop.php?id1=<?php echo $_GET['id1']?>&start=100&end=500">&#8377;100- &#8377;500 </a></li>
		                                <li><a href="shop.php?id1=<?php echo $_GET['id1']?>&start=500&end=1000">&#8377;500 - &#8377;1000 </a></li>
		                                <li><a href="shop.php?id1=<?php echo $_GET['id1']?>&start=1000&end=1500">&#8377;1000 - &#8377;1500</a></li>
		                            </ul>
		                        </form>
		                    </div>
		                </div>
		                <!--Color Category Widget End-->
		                
		                <!--Banner Widget Start-->
		                <div class="shop-sidebar">
                            <div class="sidebar-banner single-banner">
		                        <div class="banner-img">
		                            <a href="#"><img src="img/banner/shop-sidebar.jpg" alt=""></a>
		                        </div>
		                    </div>
		                </div>
		                <!--Banner Widget End-->
		                
		            </div>
		            <div class="col-lg-9 order-1 order-lg-2">
		                <div class="shop-layout">
                           <!--Breadcrumb One Start-->
                            <div class="breadcrumb-one mb-120">
                                <div class="breadcrumb-img">
                                    <img src="img/page-banner/shop-banner-1.jpg" alt="">
                                </div>
                                <div class="breadcrumb-content">
                                    <ul>
                                        <li><a href="home.php">Home</a></li>
                                        <li class="active">Shop</li>
                                    </ul>
                                </div>
                            </div>
                           <!--Breadcrumb One End-->
		                    <!--Grid & List View Start-->
		                    <div class="shop-topbar-wrapper d-md-flex justify-content-md-between align-items-center">
		                        <div class="grid-list-option">
		                             <ul class="nav">
                                      <li>
                                        <a class="active" data-toggle="tab" href="#grid"><i class="fa fa-th-large"></i></a>
                                      </li>
                                      
                                    </ul>
		                         </div>
		                         
		                    </div>
		                    <!--Grid & List View End-->
		                    <!--Shop Product Start-->
							<?php 
							if(isset($_GET['id']))
							{
								$id=$_GET['id'];
								$sql="select * from datatables_product p JOIN datatables_category c  JOIN datatables_product_details pd 
								where p.category_id_id=c.id  and
								p.id=pd.product_id_id AND p.category_id_id=$id";
							
							}
							
							if(isset($_GET['id1']))
								
							{
									$id=$_GET['id1'];
									$sql="select * from datatables_product p JOIN datatables_category c  JOIN datatables_product_details pd 
											where p.category_id_id=c.id  and
											p.id=pd.product_id_id AND c.parent_category_id=$id";
											
											
											
							}
							
								
							
							
								if(isset($_GET['id1']) && isset($_GET['start']) && isset($_GET['end']))
							{
								$id=$_GET['id1'];
								
								$s=$_GET['start'];
								$e=$_GET['end'];
								$sql="select * from datatables_product p JOIN datatables_category c join datatables_product_details pd
								 where 
								p.category_id_id=c.id and p.id=pd.product_id_id  
								and c.parent_category_id=$id 
								and pd.product_price between $s and $e";
									
									
							}
								$result = mysqli_query($conn, $sql);
							
							?>
							
		                    <div class="shop-product">
		                        <div id="myTabContent-2" class="tab-content">
		                            <div id="grid" class="tab-pane fade show active">
		                                <div class="product-grid-view">
		                                    <div class="row">
											<?php
													while($row=mysqli_fetch_array($result))
													{
														
							
													?>
		                                        <div class="col-md-4">
		                                            <!--Single Product Start-->
													
                                                    <div class="single-product mb-25">
													<?php
														$product_id = $row['product_id_id'];
														$query_images = "SELECT * FROM datatables_gallary WHERE product_id_id = {$product_id} LIMIT 1";
														$result_gallary1 = mysqli_query($conn,$query_images);
														while($gallary_row=mysqli_fetch_assoc($result_gallary1))
														{
								
														?>
														
                                                        <div class="product-img img-full">
															
                                                            <a href="single-product.php?id=<?php echo $product_id?>&sid=<?php echo $id?>">
                                                                <img src="../gallary/<?php echo $gallary_row['gallary_path']?>" alt="">
                                                            </a>
                                                            
 
                                                        </div>
														
                                                        <div class="product-content">
                                                            <h2><a href="single-product.php?id=<?php echo $product_id?>&sid=<?php echo $id?>"><?php echo $row['product_name']?></a></h2>
                                                            <div class="product-price">
                                                                <div class="price-box">
                                                                    <span class="regular-price">&#8377;<?php echo $row['product_price']?></span>
                                                                </div>
                                                                
                                                            </div>
                                                        </div>
														<?php } ?>
                                                    </div>
													
                                                    <!--Single Product End-->
		                                        </div>
												<?php }?>
		                                        
		                                       
		                                        
		                                        
		                                    </div>
		                                </div>
		                            </div>
		                            
		                           
		                        </div>
		                    </div>
		                    <!--Shop Product End-->
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Shop Area End-->
		<?php include("footer.php");?>